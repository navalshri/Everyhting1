package com.cg.demo;

public class EmployeeService {
	
	private EmployeeDAO Dao;

	public EmployeeDAO getDao() {
		return Dao;
	}

	public void setDao(EmployeeDAO dao) {
		this.Dao = dao;
	}

}



