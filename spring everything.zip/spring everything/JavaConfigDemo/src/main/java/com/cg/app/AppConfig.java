//this is java cinfig fiel which acts as a replacement of spring.xml


package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;

@Configuration//this is replacement of SPRINGxml
public class AppConfig {

	@Bean//Define a bean
	
	//syntax:public<className> <BeanID>() {....}
	public EmployeeDAO dao() {
		return new EmployeeDAO();
		
	}
	@Bean
	public EmployeeService service() {
		EmployeeService service=new EmployeeService();
		service.setDao(dao());//setter injection with java syntax!!
		return service;
		}
}


