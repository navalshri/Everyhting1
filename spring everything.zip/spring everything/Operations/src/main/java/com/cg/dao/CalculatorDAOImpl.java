package com.cg.dao;

import org.springframework.stereotype.Repository;

import com.cg.entities.EntityNumbers;
import com.cg.entities.EntityResult;
@Repository
public class CalculatorDAOImpl implements CalculatorDAO{
	EntityResult er=new EntityResult();

	@Override
	public boolean  add(EntityNumbers entitynumber) {
		double N1=entitynumber.getNumber1();
		Double n1=new Double(N1);
		double N2=entitynumber.getNumber2();
		Double n2=new Double(N2);
		if ((n1==null)||(n2==null))
		{
			throw new RuntimeException("Number cannot be empty");
		}
		else
		{double result=N1+N2;
		er.setResult(result);
		er.setInfo("result of Addition");
		return true;
		}
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public boolean subtract(EntityNumbers entitynumber) {
		double N1=entitynumber.getNumber1();
		Double n1=new Double(N1);
		double N2=entitynumber.getNumber2();
		Double n2=new Double(N2);
		if ((n1==null)||(n2==null))
		{
			throw new RuntimeException("Number cannot be empty");
		}
		else
		{double result=N1-N2;
		er.setResult(result);
		er.setInfo("result of Addition");
		return true;
		}
		
	}

	@Override
	public boolean multiply(EntityNumbers entitynumber) {
		double N1=entitynumber.getNumber1();
		Double n1=new Double(N1);
		double N2=entitynumber.getNumber2();
		Double n2=new Double(N2);
		if ((n1==null)||(n2==null))
		{
			throw new RuntimeException("Number cannot be empty");
		}
		else
		{double result=N1*N2;
		er.setResult(result);
		er.setInfo("result of multiplication");
		return true;
		}
	}

	@Override
	public boolean divide(EntityNumbers entitynumber) {
		double N1=entitynumber.getNumber1();
		Double n1=new Double(N1);
		double N2=entitynumber.getNumber2();
		Double n2=new Double(N2);
		if ((n1==null)||(n2==null))
		{
			throw new RuntimeException("Number cannot be empty");
		}
		else
		{double result=N1/N2;
		er.setResult(result);
		er.setInfo("result of Division");
		return true;
		}
	}
}

