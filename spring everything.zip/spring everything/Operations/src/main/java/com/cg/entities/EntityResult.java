package com.cg.entities;

import javax.persistence.*;

@Entity
@Table(name="result")
public class EntityResult {
	@ManyToOne
	@JoinColumn(name="EntityNumbers.Number_1")
	private EntityNumbers Number1;
	@ManyToOne
	@JoinColumn(name="EntityNumbers.Number_2")
	private EntityNumbers Number2;
	@Id
	private double result;
	@Column(name="Operation")
	private String info;
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public double getResult() {
		return result;
	}
	public void setResult(double result) {
		this.result = result;
	}
	public EntityResult(EntityNumbers number1, EntityNumbers number2, double result) {
		super();
		Number1 = number1;
		Number2 = number2;
		this.result = result;
	}
	public EntityResult() {
		super();
		// TODO Auto-generated constructor stub
	}

}
