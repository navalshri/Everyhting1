package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.EntityNumbers;
import com.cg.service.CalculatorService;
@RestController
@RequestMapping(value="/calculator")
public class CalculatorController {
	
	@Autowired CalculatorService service;
	@PostMapping(value="/add",consumes= {"application/json"})
	public String add(@RequestBody EntityNumbers entitynumbers) {
		 service.add(entitynumbers);
		 return "Added";
		
		
	}

	
	@PostMapping(value="/subtract")
	public String subtract(@RequestBody EntityNumbers entitynumbers) {
		service.subtract(entitynumbers);
		return "Subtracted";
		
	}
	
	@PostMapping(value="/multiply")
	public String multiply(@RequestBody EntityNumbers entitynumbers) {
	 service.multiply(entitynumbers);
	return "Multiplied";	
		
	}
	
	@PostMapping(value="/divide")
	public String divide(@RequestBody EntityNumbers entitynumbers) {
		 service.divide(entitynumbers);
		return "Divided";
		
	}
	 
}
