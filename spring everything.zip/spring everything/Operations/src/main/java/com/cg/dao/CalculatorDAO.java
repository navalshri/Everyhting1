package com.cg.dao;




import com.cg.entities.EntityNumbers;




public interface CalculatorDAO {
	public boolean add(EntityNumbers entitynumber);
	public boolean subtract(EntityNumbers entitynumber);
	public boolean multiply(EntityNumbers entitynumber);
	public boolean divide(EntityNumbers entitynumber);
	

}
