package com.cg.service;

import com.cg.entities.EntityNumbers;
import com.cg.entities.EntityResult;

public interface CalculatorService {
	public boolean add(EntityNumbers entitynumbers);
	public boolean subtract(EntityNumbers entitynumbers);
	public boolean multiply(EntityNumbers entitynumbers);
	public boolean divide(EntityNumbers entitynumbers);

}
