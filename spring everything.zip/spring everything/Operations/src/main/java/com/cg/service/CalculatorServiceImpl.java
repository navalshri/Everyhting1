package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.CalculatorDAO;
import com.cg.dao.CalculatorDAOImpl;
import com.cg.entities.EntityNumbers;
import com.cg.entities.EntityResult;

@Service
public class CalculatorServiceImpl implements CalculatorService{
	EntityResult er=new EntityResult();
	
	
	@Autowired private CalculatorDAOImpl dao;

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean add(EntityNumbers entitynumbers) {
		 dao.add(entitynumbers);
		 return true;
	}
	
	@Override
	public boolean subtract(EntityNumbers entitynumbers) {
		 dao.subtract(entitynumbers);
		 return true;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean multiply(EntityNumbers entitynumbers) {
		 dao.multiply(entitynumbers);
		 return true;
	}

	@Override
	public boolean divide(EntityNumbers entitynumbers) {
		 dao.divide(entitynumbers);
		 return true;
	}

}
