package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Numbers")
public class EntityNumbers {
	@Id
	@Column(name="Number_1")
	private double Number_1;
	@Column(name="Number_2")
	private double Number_2;
	public double getNumber1() {
		return Number_1;
	}
	public void setNumber1(double number1) {
		this.Number_1 = number1;
	}
	public double getNumber2() {
		return Number_2;
	}
	public void setNumber2(double number2) {
		this.Number_2 = number2;
	}
	public EntityNumbers(double number1, double number2) {
		super();
		Number_1 = number1;
		Number_2 = number2;
	}
	public EntityNumbers() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
