package com.cg.entities;

import javax.persistence.*;


@Entity
@Table(name="products")

public class Product {
	@Id
	private int productId;
	@Column(name="name", length=20)
	private String name;
	@Column(name="description" ,length=50)
	
	private String description;
	@Column(name="price")
	private double price;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Product(int productId, String name, String description, double price) {
		super();
		this.productId = productId;
		this.name = name;
		this.description = description;
		this.price = price;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

}
