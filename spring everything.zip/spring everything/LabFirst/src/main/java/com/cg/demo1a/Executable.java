package com.cg.demo1a;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Executable {

	public static void main(String[] args) {
		ApplicationContext factory=new ClassPathXmlApplicationContext("Spring.xml");
		Employee Emp= (Employee) factory.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("----------------------");
		System.out.println("Emplyee ID:"+Emp.getEmployeeID());
		System.out.println("Emplyee Name:"+Emp.getEmployeeName());
		System.out.println("Employee Salary:"+Emp.getSalary());
		System.out.println("Employee BU:"+Emp.getBU());
		System.out.println("Employee Age:"+ Emp.getAge());
		
		
		
	}

}
