package com.cg.demo1a;

public class Employee {
	private int EmployeeID;
	private String EmployeeName;
	private double Salary;
	private String BU;
	private int age;
	
	
	public int getEmployeeID() {
		return EmployeeID;
	}
	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getBU() {
		return BU;
	}
	public void setBU(String bU) {
		BU = bU;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int employeeID, String employeeName, double salary, String bU, int age) {
		super();
		EmployeeID = employeeID;
		EmployeeName = employeeName;
		Salary = salary;
		BU = bU;
		this.age = age;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
