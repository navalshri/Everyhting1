package com.cg.controllers;
import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
@RestController
public class HelloController {
	@GetMapping(value="/")
	public String hello()
	{
		return "Hello world";	
	}
	
	@GetMapping(value="/products")
	public List<Product> getProucts(){//this getProducts() is just the method name and can be anything abc, xyz. and list<> is a format of describing any function of list. obj.add new product is a way of adding new product in the list
		List<Product> list= new LinkedList<Product>();
		list.add(new Product(101,"Windows 10pro","64 bit os for desktop and laptop",8000));
		list.add(new Product(102,"ubuntu","64 bit os for desktop and laptop",9000));
		list.add(new Product(103,"linux","64 bit os for desktop and laptop",10000));
		return list;
		
	}
	
	
	
	
	}
//this home.controller will only work with GetMapping and not with request mapping because it is not home or parent it is a child