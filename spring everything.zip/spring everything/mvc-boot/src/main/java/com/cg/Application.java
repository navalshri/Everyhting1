package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		
		/*this single line(SpringApplicatin.run) does following things
		 * creates annotation AnnotstionconfigApplicationContext
		 * it uses componenet scan for all child packages
		 * it picks up hello controller clas 
		 * does request mapping for("/")
		 * it reds application.properties
		 * forund one property "server.port=1313"
		 * launches embedded tomcat server and deploy hello controller
		 * wait for you to terminate the  process
		 */
		
		
		SpringApplication.run(Application.class);

	}

}
