package com.cg.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Coupon;
import com.cg.entity.User1;
import com.cg.service.CouponService;
@RestController
@RequestMapping(value="/coupon")
public class CouponController {
	@Autowired CouponService service;
	 @GetMapping(value="/check/{userId}")	
	    public Coupon getbyid(@PathVariable("userId") Integer id) 
	 {
	        return service.getcoupon(id);
	    
	 }

	    
	    @GetMapping(value="/apply/{userId}")	
	    public String findbycode(@PathVariable("userId") Integer id ) {
	        service.applycoupon(id);
	        return "Coupon Applied";
	    }
	
	

}
