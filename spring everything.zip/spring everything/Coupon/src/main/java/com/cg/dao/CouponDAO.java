package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.entity.Coupon;
import com.cg.entity.User1;
@Repository

public interface CouponDAO extends JpaRepository<Coupon, Integer> {
	@Query("select c from Coupon c where c.user.userId=?1")
	public Coupon getcoupon(int id);
	@Query("select c.discount from Coupon c where c.user.userId=?1")
	public double getdiscount(int id) ;
}
