package com.cg.AnnotationDemo;

import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Repository;
@Component
//@Repository

public class EmployeeDao {

}
