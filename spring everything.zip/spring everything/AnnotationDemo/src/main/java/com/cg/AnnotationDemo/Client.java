package com.cg.AnnotationDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeDao dao=context.getBean(EmployeeDao.class);
		EmployeeService service= context.getBean(EmployeeService.class);
		System.out.println("Dao"+ dao.hashCode());
		System.out.println("Service:"+service.hashCode());
		

	}

}
