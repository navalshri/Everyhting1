package com.cg.AnnotationDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Service;

@Component
//@Service
public class EmployeeService {

	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}
	@Autowired
	public void setDao(EmployeeDao dao) {
		System.out.println("performing setter Injection");
		this.dao = dao;
		
	}
	
}
