package com.cg.dao;

public  class CounrtyDAOImpl implements CountryDAO {

	public void save(Country country) {
		// TODO Auto-generated method stub
		
	}

}
