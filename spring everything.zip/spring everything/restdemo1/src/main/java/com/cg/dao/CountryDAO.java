package com.cg.dao;

public interface CountryDAO {
	void save(Country country);
	Country
	List<Country>
	void U

}
