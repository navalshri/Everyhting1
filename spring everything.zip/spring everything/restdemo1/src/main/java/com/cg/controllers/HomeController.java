package com.cg.controllers;

import java.util.Date;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Message;

@RestController
@RequestMapping(value="/test")
public class HomeController {
	Message message=new Message();
	@GetMapping(value="/" ,produces= {"application/json","application/xml"})
	public Message testget()
	{	

	message.setText("this is get message");
	message.setDate(new Date());
	return message;
	}
	@PutMapping(value="/" ,produces= {"application/json","application/xml"})
	public Message testput()
	{
	 message.setText("This is put request");
	 message.setDate(new Date());
		return message;
	
	}
	
	@PostMapping(value="/" ,produces= {"application/json","application/xml"})
	public String testpost()
	{
		return "This is post request";
		
	}
	
	@DeleteMapping(value="/" ,produces= {"application/json","application/xml"})
	public String testdelete()
	{
		return "This is delete request";
	}
	
	@PatchMapping(value="/" ,produces= {"application/json","application/xml"})
	public String testpatch()
	{
		return "This is patch request";
	}
	
	

}
