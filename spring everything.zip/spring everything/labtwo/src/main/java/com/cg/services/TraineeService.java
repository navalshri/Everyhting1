package com.cg.services;

import java.util.List;

import com.cg.entities.TraineeEntity;

public interface TraineeService {
	public void add(TraineeEntity te);
	
	public TraineeEntity Retrieve(int TID);
	public List<TraineeEntity> Retrieveall();
	public TraineeEntity modify(int traineeId);

}
