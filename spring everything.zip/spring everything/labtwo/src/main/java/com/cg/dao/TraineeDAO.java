package com.cg.dao;

import java.util.List;

import com.cg.entities.TraineeEntity;

public interface TraineeDAO {
	public void add(TraineeEntity te);
	
	public TraineeEntity Retrieve(int TID);
	public List<TraineeEntity> Retrieveall();
	public TraineeEntity modify(int traineeId);
	

}
