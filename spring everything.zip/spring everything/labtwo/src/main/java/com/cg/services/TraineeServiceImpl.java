package com.cg.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.TraineeDAOImpl;
import com.cg.entities.TraineeEntity;
@Service
public class TraineeServiceImpl implements TraineeService
{
@Autowired TraineeDAOImpl dao;
@Transactional(propagation=Propagation.REQUIRED)
	public void add(TraineeEntity te) {
		
		dao.add(te);
	}

	

	

	public TraineeEntity Retrieve(int TID) {
		
		return dao.Retrieve(TID);
	}

	public List<TraineeEntity> Retrieveall() {
		// TODO Auto-generated method stub
		return dao.Retrieveall();
	}

	public TraineeEntity modify(int traineeId) {
		// TODO Auto-generated method stub
		return null;
	}



	
}
