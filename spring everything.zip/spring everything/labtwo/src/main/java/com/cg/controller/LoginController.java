package com.cg.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Entity;
import com.cg.entities.TraineeEntity;
import com.cg.services.TraineeServiceImpl;

@Controller
@RequestMapping
public class LoginController {
	
	@Autowired TraineeServiceImpl service;
	@GetMapping("/")
	public String login(Model model, @ModelAttribute("trainee")Entity entity ) {
		System.out.println("Hello1");
		model.addAttribute("check","Login Page");
		return "login";
	}
	@PostMapping("/")
	public String entry(Model model,  @ModelAttribute("trainee") Entity entity){
		System.out.println("Hello");
		if(entity.getUsername().equals("naval")&& (entity.getPassword().equals("naval")))
	
		{
		model.addAttribute("qwe","Trainee Management System");
		return "entry";
		}
		else {
			model.addAttribute("check","Please enter username and password correctly");
			return "login";
		}
		
	}
	
	
	@GetMapping(value="/delete")
	public String delete(Model model, @ModelAttribute("nav") TraineeEntity traineeentity, BindingResult results){
		System.out.println("aaaa");
		model.addAttribute("abc","Delete Operation");
	    return "delete";
	}
	
	
	////add done
	@GetMapping(value="/add")
	public String add(Model model,@ModelAttribute("xyz") TraineeEntity traineeentity, BindingResult results){
		System.out.println("bbbbb");
		model.addAttribute("xyz",new TraineeEntity());
	    return "add";
	}
	@PostMapping(value="/add")
	public String add1(Model model,@ModelAttribute("xyz") TraineeEntity traineeentity, BindingResult results){
		service.add(traineeentity);
		model.addAttribute("xyz",new TraineeEntity());
	    return "add";
	}///add done
	
	
	@GetMapping(value="/modify")
	public String modify(Model model, @ModelAttribute("aaa") TraineeEntity traineeentity, BindingResult results){
		System.out.println("aaaa");
		model.addAttribute("aaa","Modify Operation");
	    return "modify";
	}
	@PostMapping(value="/modify")
	public String modify1(Model model, @RequestParam("u")int id){
		TraineeEntity rt=service.modify(id);
		model.addAttribute("aaa",rt);
	    return "modify";
	}
	////retrieve done
	@GetMapping(value="/retrieve")
	public String retrieve(Model model, @ModelAttribute("bbb") TraineeEntity traineeentity, BindingResult results){
		System.out.println("sgggr");
		model.addAttribute("abc","Retrieve Operation");
	    return "retrieve";
	}
	    @PostMapping(value="/retrieve")
		public String retrieve1(Model model, @RequestParam("traineeId")int id){
			TraineeEntity tr=service.Retrieve(id);
			
			model.addAttribute("bbb",tr);
		    return "retrieve";
}  /////retrieve done
	    
	    
	    /////retrieveall done
	@GetMapping(value="/retrieve all")
	public String retrieveall(Model model, @ModelAttribute("ccc") TraineeEntity traineeentity, BindingResult results){
		System.out.println("sgggr");
		model.addAttribute("abc","Trainee Details");
	    return "retrieveall";
	}
	    @PostMapping(value="/retrieve all")
		public String retrieveall1(Model model){
			List<TraineeEntity> afg=service.Retrieveall();
		    model.addAttribute("ccc",afg);
		    return "retrieveall";
	}
	
	    /////retrieveall done

}
