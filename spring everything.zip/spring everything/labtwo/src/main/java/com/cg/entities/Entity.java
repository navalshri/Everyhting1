package com.cg.entities;





public class Entity {

	private String Username;

	private String password;

	public Entity(String username, String password) {
		super();
		this.Username = username;
		this.password = password;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		this.Username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public Entity() {
		super();
		// TODO Auto-generated constructor stub
	}

}
