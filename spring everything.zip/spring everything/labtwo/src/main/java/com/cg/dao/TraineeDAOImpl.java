package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.TraineeEntity;
@Repository
public class TraineeDAOImpl implements TraineeDAO {
private EntityManager em;
	public void add(TraineeEntity te) {
		  em.persist(te);
	        em.flush();
		
	}

	public TraineeEntity delete(int tid) {
		TraineeEntity t=em.find(TraineeEntity.class,tid);
		return t;
	}

	public TraineeEntity Retrieve(int TID) {
		TraineeEntity t=em.find(TraineeEntity.class,TID);
		return t;
		

	}

	public List<TraineeEntity> Retrieveall() {
		Query query=em.createQuery("from TraineeEntity t");
		return query.getResultList();
	}

	public TraineeEntity modify(int traineeId) {
		TraineeEntity t=em.find(TraineeEntity.class,traineeId);
		return t;
	}

	public void finaldelete(TraineeEntity te) {
		
				em.remove(te);
			
		
		
	}
	

}
