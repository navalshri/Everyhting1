package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {
//main class to run the application
	public static void main(String args[]) {
		SpringApplication.run(Main.class,args);
	}
}
