package com.cg.daos;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.entities.Product;
public interface ProductDAO extends JpaRepository<Product, String>{
	
}
