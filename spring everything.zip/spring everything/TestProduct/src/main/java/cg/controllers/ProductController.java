package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
import com.cg.services.ProductServiceImpl;

@RestController
@RequestMapping("/Product")
public class ProductController {

    @Autowired ProductServiceImpl service;
  //to find a product by id
    @GetMapping(value="/id/{id}")	
    public Product findbyid(@PathVariable String id) {
        return service.findbyid(id);
    }

  //to add a products
    @PostMapping(value="/new",consumes= {"application/json"})
    public String save(@RequestBody Product product) {
        service.create(product);
        return "Product added!";
    }
  //to update the products
    @PutMapping(value="/update/{id}",consumes= {"application/json"})
    public String update(@PathVariable String id) {
    	Product product=service.findbyid(id);
        service.update(product);
        return "Product updated";
    }  
  //to delete product
    @DeleteMapping(value="/delete/{id}", consumes= {"application/json"})
    public String delete(@PathVariable String id) {
    	Product product=service.findbyid(id);
    	service.deleteById(product);
    	
    	return "Product deleted";
    	
    }
  //to list all the products
    @GetMapping(value="/Product")
    public List<Product> prouct(String id)  {
    return service.byId(id);
    
    
}
}