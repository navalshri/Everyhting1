package com.cg.services;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.ProductDAO;

import com.cg.entities.Product;


@Service
@Transactional
public class ProductServiceImpl implements Productservice {

    @Autowired private ProductDAO dao;

    @Transactional(readOnly=true)//to return all the products
    public List<Product> byId(String id) {
    	List<Product> product = dao.findAll();
            return product;
    }
      
    public void update(Product p) {// to update the product with the same id
    	dao.save(p);
                 
    }
    
    
    public void create(Product p) {//	to create a new product
    	dao.save(p);
    }
    
    public void deleteById(Product p) {// to delete an existing product
    	dao.delete(p);
    }
    
    
    @Transactional(readOnly=true)
    public Product findbyid(String id) {//to return a single product
    	Optional<Product> product = dao.findById(id);
    	if(product.isPresent()) {
            return product.get();
        }
        else
            throw new RuntimeException("Product not found!");//exception handling
    }
    
}
