package com.cg.services;

import java.util.List;

import com.cg.entities.Product;

public interface Productservice {
	  public List<Product> byId(String id);
	  public void update(Product p);
	  public void create(Product p);
	  public void deleteById(Product p);
	  public Product findbyid(String id);

}
