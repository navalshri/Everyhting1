package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//entity class 
@Entity
@Table(name="Product")
public class Product {

	@Id//primary key
	private String productId;
	@Column(name="name",length=20)
	private String productName;//name of length 20
	@Column(name="model",length=20)
	private String productModel;//name of length 20
	@Column(name="price")
	private double productPrice;//name of length 20
	
	
	///getter and setter
	public String getid() {
		return productId;
	}
	public void setid(String id) {
		this.productId = id;
	}
	public String getName() {
		return  productName;
	}
	public void setName(String name) {
		this. productName = name;
	}
	public String getmodel() {
		return productModel;
	}
	public void setmodel(String model) {
		this.productModel = model;
	}
	public double getprice() {
		return productPrice;
	}
	public void setprice(double price) {
		this.productPrice = price;
	}
	public Product() {//constructor using class
		super();
		
	}
	public Product(String id, String name, String model, double price) {//constructor using field
		super();
		this. productId = id;
		this. productName = name;
		this.productModel = model;
		this.productPrice = price;
	}
	
	
}