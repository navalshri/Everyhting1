package com.cg.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	private EmployeeDAO Dao;

	public EmployeeDAO getDao() {
		return Dao;
	}
@Autowired
	public void setDao(EmployeeDAO dao) {
		this.Dao = dao;
}
}
