package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.entity.Coupon;
import com.cg.entity.User1;

public interface UserDAO extends JpaRepository<User1, Integer>{
	@Query("select u from User1 u where u.userId=?1")
	public User1 getuser(int id);

}
