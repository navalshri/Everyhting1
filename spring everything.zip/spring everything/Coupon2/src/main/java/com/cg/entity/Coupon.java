package com.cg.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="coupon")
public class Coupon {
	@Id
	private Integer couponid;
	
	@Column(length=50,nullable=false)
	private String couponName;
	
	@Column
	private Integer userId;
	
	@Column(nullable=false)
	private Double discount;

	
	public Coupon() {
		// TODO Auto-generated constructor stub
	}




	public Integer getCouponid() {
		return couponid;
	}


	public void setCouponid(Integer couponid) {
		this.couponid = couponid;
	}


	public String getCouponName() {
		return couponName;
	}


	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}


	


	public Integer getUser() {
		return userId;
	}




	public void setUser(Integer userId) {
		this.userId = userId;
	}




	public Double getDiscount() {
		return discount;
	}


	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	
	


	
	
	
}
