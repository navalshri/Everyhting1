package com.cg.service;



import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.CouponDAO;
import com.cg.dao.UserDAO;
import com.cg.entity.Cart;
import com.cg.entity.Coupon;
import com.cg.entity.User1;

@Service
public class CouponService{
	Cart cart=new Cart();
	Date date=new Date();
	@Autowired private CouponDAO dao;
//	@Autowired private UserDAO dao1;
	 @Transactional(readOnly=true)
	public Coupon getcoupon(int id)
	
	{
	//	 User1 user=dao1.getuser(id);
		 Coupon c = dao.getcoupon(id);
		 if(c==null)
		 {
			 throw new RuntimeException( "Coupon not found"); 
		 }
		 else {
			 return c;
		 }
	}
	 
	 
	/*	public double applycoupon(int id)
		{
			//User1 user= dao1.getuser(id);
			 Coupon c = dao.getcoupon(id);
			double discount=c.getDiscount();
			double price=cart.getAmount();
			if(((c.getStartDate().compareTo(date))>0)&&((c.getEndDate().compareTo(date)))<0)
			{ 
				price=price-c.getDiscount();
				cart.setAmount(price);
			return price;
		
			}
			else
			{
				throw new RuntimeException( "Coupon not found");
		
				
			
		}
		
	}*/
	
	

}