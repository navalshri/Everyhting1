package com.cg.Exception;

public class Exception extends RuntimeException {

	public Exception(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

	
	

}
